/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20201108;

/**
 *
 * @author xvpow
 */
public class Ch1_7 {
   
    public static void main(String[] args) {
	//複合指定運算子特殊
	int v1 = 10;
	v1 += 2;
	//v1 = v1 + 2.5;
	v1 += 2.5;
	System.out.println(v1);
    }   
}
