/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ch1_20201108;


public class Ch1_12 {   
    
    public static void main(String[] args) {
	//1,2,4
	//3,2,4
	//執行順序
	//for 三區塊
	// (初始化或宣告;可進入迴圈條件;累加累減)
	for (int i =1 ; i<=5 ; i++ ){
	    System.out.println(i);//1 2 3 4 5
	}	
    }
    
}
